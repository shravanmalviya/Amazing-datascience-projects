# AnalyticsVidhya's Black Friday Data Hack

Online data science hackathon held Nov 20-22 by Analytics Vidhya. 
http://datahack.analyticsvidhya.com/contest/black-friday-data-hack/
