# Boston-Housing-EDA
Exploratory Data Analysis on Boston Housing Dataset . This data set contains the data collected by the U.S Census Service for housing in Boston, Massachusetts.
